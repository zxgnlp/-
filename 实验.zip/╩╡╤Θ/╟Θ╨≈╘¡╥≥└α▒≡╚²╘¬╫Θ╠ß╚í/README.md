在下面链接中下载chatglm3-6b模型

[zai-org/ChatGLM3: ChatGLM3 series: Open Bilingual Chat LLMs | 开源双语对话语言模型](https://github.com/zai-org/ChatGLM3)

在该链接中可以找到glm3-6b的微调介绍和微调方法





下载完成后有下列文件![image-20260115102727328](C:\Users\Administrator\AppData\Roaming\Typora\typora-user-images\image-20260115102727328.png)

运行代码部分在该目录下finetune_demo中的lora_finetune.ipynb文件中。

将该文件夹中的finetune_hf2.py和inference2.py放到  finetune_demo目录下。
