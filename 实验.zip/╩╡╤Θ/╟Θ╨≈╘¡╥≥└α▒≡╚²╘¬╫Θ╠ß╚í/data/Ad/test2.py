#计算三元组的prf 和词语级的prf
import re
import json


def extract_triplets_from_predictions(pred_file_path: str) -> list:
    """
    从预测结果中提取三元组
    预测文件格式为直接输出的三元组字符串列表。
    """
    with open(pred_file_path, 'r', encoding='utf-8') as f:
        pred_list = json.load(f)

    # 使用正则表达式提取三元组
    triplet_regex = r"\['(.*?)', '(.*?)', '(.*?)'\]"
    pred_triplets = []
    for pred in pred_list:
        matches = re.findall(triplet_regex, pred)
        pred_triplets.append(matches)
    return pred_triplets


def extract_triplets_from_test_file(test_file_path: str) -> list:
    """
    从真实标签文件中提取三元组
    测试文件为多行 JSON，每行是一个独立的 JSON 对象。
    """
    true_triplets = []
    with open(test_file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip():  # 跳过空行
                continue
            try:
                test_data = json.loads(line.strip())  # 逐行解析 JSON
                for conversation in test_data.get("conversations", []):
                    if conversation["role"] == "assistant":
                        # 提取三元组部分
                        matches = re.findall(r"\['(.*?)', '(.*?)', '(.*?)'\]", conversation["content"])
                        true_triplets.append(matches)
            except json.JSONDecodeError as e:
                print(f"JSONDecodeError: {e} in line: {line}")
    return true_triplets


def get_correct_words(true: str, pred: str) -> int:
    m = len(true)
    n = len(pred)

    # 创建 (m+1) x (n+1) 的动态规划表格，初始值为0
    dp = [[0] * (n + 1) for _ in range(m + 1)]

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if true[i - 1] == pred[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])

    return dp[m][n]


def calculate_prf_with_word_level(pred_triplets: list, true_triplets: list) -> tuple:
    """
    计算三元组级别和词语级别的 P、R、F1 值
    """
    # 三元组级别指标
    correct_triplets = 0
    total_pred_triplets = sum(len(triplets) for triplets in pred_triplets)
    total_true_triplets = sum(len(triplets) for triplets in true_triplets)

    # 词语级别指标
    correct_emo_words = 0
    correct_cause_words = 0
    pred_emo_words = 0
    pred_cause_words = 0
    true_emo_words = 0
    true_cause_words = 0

    # 比较三元组和统计词语级别的匹配
    for pred_list, true_list in zip(pred_triplets, true_triplets):
        for pred in pred_list:
            for true in true_list:
                if pred == true:
                    correct_triplets += 1
                if pred[2] == true[2]:  # 极性相同时进行片段级别匹配
                    correct_emo_words += get_correct_words(true[0], pred[0])
                    correct_cause_words += get_correct_words(true[1], pred[1])

            pred_emo_words += len(pred[0])
            pred_cause_words += len(pred[1])

        for true in true_list:
            true_emo_words += len(true[0])
            true_cause_words += len(true[1])

    # Precision, Recall, F1 for triplets
    precision_t = correct_triplets / total_pred_triplets if total_pred_triplets > 0 else 0
    recall_t = correct_triplets / total_true_triplets if total_true_triplets > 0 else 0
    f1_t = (2 * precision_t * recall_t) / (precision_t + recall_t) if (precision_t + recall_t) > 0 else 0

    # Precision, Recall for words
    emo_words_p = correct_emo_words / pred_emo_words if pred_emo_words > 0 else 0
    emo_words_r = correct_emo_words / true_emo_words if true_emo_words > 0 else 0
    cause_words_p = correct_cause_words / pred_cause_words if pred_cause_words > 0 else 0
    cause_words_r = correct_cause_words / true_cause_words if true_cause_words > 0 else 0

    # Average word-level Precision and Recall
    words_p = (emo_words_p + cause_words_p) / 2
    words_r = (emo_words_r + cause_words_r) / 2
    words_f = (2 * words_p * words_r) / (words_p + words_r) if (words_p + words_r) > 0 else 0

    return precision_t, recall_t, f1_t, words_p, words_r, words_f


def count_cause_fragments(triplets: list) -> int:
    """
    统计原因片段的数量
    """
    count = 0
    for triplet_list in triplets:
        for triplet in triplet_list:
            if len(triplet) > 1:
                count += 1
    return count


def calculate_cause_prf(pred_triplets: list, true_triplets: list) -> tuple:
    """
    计算原因片段的 PRF 指标
    """
    correct_cause_chars = 0
    total_pred_cause_chars = 0
    total_true_cause_chars = 0

    for pred_list, true_list in zip(pred_triplets, true_triplets):
        for pred in pred_list:
            if len(pred) > 1:
                total_pred_cause_chars += len(pred[1])
                for true in true_list:
                    if len(true) > 1:
                        correct_cause_chars += get_correct_words(true[1], pred[1])

        for true in true_list:
            if len(true) > 1:
                total_true_cause_chars += len(true[1])

    precision_cause = correct_cause_chars / total_pred_cause_chars if total_pred_cause_chars > 0 else 0
    recall_cause = correct_cause_chars / total_true_cause_chars if total_true_cause_chars > 0 else 0
    f1_cause = (2 * precision_cause * recall_cause) / (precision_cause + recall_cause) if (precision_cause + recall_cause) > 0 else 0

    return precision_cause, recall_cause, f1_cause


def main():
    # 文件路径
    pred_file_path = "/data/zxg/ChatGLM3/finetune_demo/data/Ad/DAresults_fold1_2.json"  # 替换为预测文件路径
    test_file_path = "/data/zxg/ChatGLM3/finetune_demo/data/Ad/res_val_fold1_2.json"  # 替换为测试文件路径

    # 提取三元组
    pred_triplets = extract_triplets_from_predictions(pred_file_path)
    true_triplets = extract_triplets_from_test_file(test_file_path)

    # 统计原因片段数量
    pred_cause_count = count_cause_fragments(pred_triplets)
    true_cause_count = count_cause_fragments(true_triplets)

    # 计算原有的 P、R、F1
    precision_t, recall_t, f1_t, words_p, words_r, words_f = calculate_prf_with_word_level(pred_triplets, true_triplets)

    # 计算原因片段的 PRF
    precision_cause, recall_cause, f1_cause = calculate_cause_prf(pred_triplets, true_triplets)

    print(f"Triplet-Level Precision: {precision_t:.4f}")
    print(f"Triplet-Level Recall: {recall_t:.4f}")
    print(f"Triplet-Level F1 Score: {f1_t:.4f}")
    print(f"Word-Level Precision: {words_p:.4f}")
    print(f"Word-Level Recall: {words_r:.4f}")
    print(f"Word-Level F1 Score: {words_f:.4f}")
    print(f"Predicted Cause Fragments Count: {pred_cause_count}")
    print(f"True Cause Fragments Count: {true_cause_count}")
    print(f"Cause Fragment Precision: {precision_cause:.4f}")
    print(f"Cause Fragment Recall: {recall_cause:.4f}")
    print(f"Cause Fragment F1 Score: {f1_cause:.4f}")


if __name__ == "__main__":
    main()