import re
import json

def extract_triplets_from_predictions(pred_file_path: str) -> list:
    """
    从预测结果中提取三元组
    预测文件格式为直接输出的三元组字符串列表。
    """
    with open(pred_file_path, 'r', encoding='utf-8') as f:
        pred_list = json.load(f)
    
    # 使用正则表达式提取三元组
    triplet_regex = r"\['(.*?)', '(.*?)', '(.*?)'\]"
    pred_triplets = []
    for pred in pred_list:
        matches = re.findall(triplet_regex, pred)
        pred_triplets.append(matches)
    return pred_triplets

def extract_triplets_from_test_file(test_file_path: str) -> list:
    """
    从真实标签文件中提取三元组
    测试文件为多行 JSON，每行是一个独立的 JSON 对象。
    """
    true_triplets = []
    with open(test_file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip():  # 跳过空行
                continue
            try:
                test_data = json.loads(line.strip())  # 逐行解析 JSON
                for conversation in test_data.get("conversations", []):
                    if conversation["role"] == "assistant":
                        # 提取三元组部分
                        matches = re.findall(r"\['(.*?)', '(.*?)', '(.*?)'\]", conversation["content"])
                        true_triplets.append(matches)
            except json.JSONDecodeError as e:
                print(f"JSONDecodeError: {e} in line: {line}")
    return true_triplets


def calculate_prf(pred_triplets: list, true_triplets: list) -> tuple:
    """
    计算三元组级别的 P、R、F1 值
    """
    correct_triplets = 0
    total_pred_triplets = sum(len(triplets) for triplets in pred_triplets)
    total_true_triplets = sum(len(triplets) for triplets in true_triplets)
    
    # 比较三元组
    for pred, true in zip(pred_triplets, true_triplets):
        for triplet in pred:
            if triplet in true:
                correct_triplets += 1

    # 计算 Precision, Recall, F1
    precision = correct_triplets / total_pred_triplets if total_pred_triplets > 0 else 0
    recall = correct_triplets / total_true_triplets if total_true_triplets > 0 else 0
    f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    
    return precision, recall, f1

def main():
    # 文件路径
    pred_file_path = "/data/zxg/ChatGLM3/finetune_demo/data/Ad/new_result.json"  # 替换为预测文件路径
    test_file_path = "/data/zxg/ChatGLM3/finetune_demo/data/Ad/val.json"  # 替换为测试文件路径

    # 提取三元组
    pred_triplets = extract_triplets_from_predictions(pred_file_path)
    true_triplets = extract_triplets_from_test_file(test_file_path)

    # 计算 P、R、F1
    precision, recall, f1 = calculate_prf(pred_triplets, true_triplets)
    print(f"Precision: {precision:.4f}")
    print(f"Recall: {recall:.4f}")
    print(f"F1 Score: {f1:.4f}")

if __name__ == "__main__":
    main()
