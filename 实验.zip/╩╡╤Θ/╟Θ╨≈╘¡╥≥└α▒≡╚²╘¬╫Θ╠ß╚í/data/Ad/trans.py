# 改 role content 里面
import json
import codecs

file_path = r'D:\Code\QWen_datamix(1)\QWen_datamix\train_fold9.json'

try:
    with open(file_path, 'r', encoding='utf-8') as file:
        original_data = json.load(file)

    new_data_list = []
    num_elements = len(original_data)
    for index in range(num_elements):
        conversations_list = original_data[index]["conversations"]
        system_content = ""
        user_content = ""
        assistant_content = ""
        gpt_count = 0
        for conversation in conversations_list:
            role = conversation["from"]
            content = conversation["value"]

            # print(f"当前处理的角色: {role}, 对应的内容: {content}")
            if role == "gpt":
                gpt_count += 1
                if gpt_count == 1:
                    system_content = content
                elif gpt_count == 2:
                    assistant_content = content
            elif role == "human":
                user_content = content

        new_data = {
            "conversations": [
                {
                    "role": "system",
                    "content": system_content
                },
                {
                    "role": "user",
                    "content": user_content
                },
                {
                    "role": "assistant",
                    "content": assistant_content
                }
            ]
        }
        new_data_list.append(new_data)

    # 这里直接使用new_data_list作为要写入的内容，不再额外包裹一层"conversations"键
    with codecs.open(r'D:\Code\QWen_datamix(1)\QWen_datamix\trans\train_fold9.json', 'w', encoding='utf-8') as new_file:  
        json.dump(new_data_list, new_file, indent=4, ensure_ascii=False)
except FileNotFoundError as e:
    print(f"文件不存在，错误信息：{e}")
except json.JSONDecodeError as e:
    print(f"JSON文件解析错误，错误信息：{e}")
except UnicodeDecodeError as e:
    print(f"文件编码解码错误，错误信息：{e}")
except Exception as e:
    print(f"出现其他未知错误，信息：{e}")