import json
import re
from pathlib import Path
from typing import Annotated, Union
import time

import typer
from peft import AutoPeftModelForCausalLM, PeftModelForCausalLM
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    PreTrainedModel,
    PreTrainedTokenizer,
    PreTrainedTokenizerFast,
)

ModelType = Union[PreTrainedModel, PeftModelForCausalLM]
TokenizerType = Union[PreTrainedTokenizer, PreTrainedTokenizerFast]

app = typer.Typer(pretty_exceptions_show_locals=False)


def _resolve_path(path: Union[str, Path]) -> Path:
    return Path(path).expanduser().resolve()


def read_json_dataset(dataset_path: Union[str, Path]) -> list[str]:
    dataset_path = _resolve_path(dataset_path)
    combined_data_list = []
    try:
        with open(dataset_path, 'r', encoding='utf-8') as file:
            file_content = file.read()
            json_data_pattern = re.compile(r'\{[^{}]*\}')
            matches = json_data_pattern.findall(file_content)
            temp_system_content = ""
            temp_user_content = ""
            for match in matches:
                try:
                    data = json.loads(match.strip())
                    if isinstance(data, dict):
                        if "role" in data and "content" in data:
                            if data["role"] == "system":
                                temp_system_content = data["content"]
                            elif data["role"] == "user":
                                temp_user_content = data["content"]
                        # 当一组system和user内容都获取到后，进行拼接并添加到最终列表
                        if temp_system_content and temp_user_content:
                            combined_content = '"' + temp_system_content + temp_user_content + '"'
                            combined_data_list.append(combined_content)
                            temp_system_content = ""
                            temp_user_content = ""
                except json.JSONDecodeError as e:
                    print(f"解析单段JSON数据时出错: {e}")
    except json.JSONDecodeError as e:
        print(f"JSON解析错误: {e}")
        raise
    except FileNotFoundError:
        print(f"文件 {dataset_path} 不存在")
    return combined_data_list


def load_model_and_tokenizer(model_dir: Union[str, Path]) -> tuple[ModelType, TokenizerType]:
    model_dir = _resolve_path(model_dir)
    if (model_dir / 'adapter_config.json').exists():
        model = AutoPeftModelForCausalLM.from_pretrained(
            model_dir, trust_remote_code=True, device_map='auto'
        )
        tokenizer_dir = model.peft_config['default'].base_model_name_or_path
    else:
        model = AutoModelForCausalLM.from_pretrained(
            model_dir, trust_remote_code=True, device_map='auto'
        )
        tokenizer_dir = model_dir
    tokenizer = AutoTokenizer.from_pretrained(
        tokenizer_dir, trust_remote_code=True
    )
    return model, tokenizer


@app.command()
def main(
        model_dir: Annotated[str, typer.Argument(help='')],
        dataset_path: Annotated[str, typer.Option(help='JSON格式数据集文件路径')],
        output_path: Annotated[str, typer.Option(help='推理结果输出文件路径')]
):
    model, tokenizer = load_model_and_tokenizer(model_dir)
    if model is None or tokenizer is None:
        print("模型或分词器加载失败，请检查相关配置和模型文件")
        return
    dataset = read_json_dataset(dataset_path)
    if not dataset:
        print("数据集为空，请检查JSON文件格式和解析逻辑")
        return
    results = []
    for data in dataset:
        print(f"开始处理数据: {data}")
        if not isinstance(tokenizer, (PreTrainedTokenizer, PreTrainedTokenizerFast)):
            print("分词器对象类型错误，请检查分词器加载和初始化")
            return
        if not isinstance(data, str) or data.strip() == "":
            print("输入数据格式错误或为空，请检查数据集和数据处理逻辑")
            return
        try:
            print("即将调用model.chat方法进行推理")
            response, _ = model.chat(tokenizer, data.strip())
            print("已完成model.chat方法调用，得到推理结果")
            results.append(response)
        except Exception as e:
            print(f"推理过程出现错误: {e}")
    with open(output_path, 'w', encoding='utf-8') as out_file:
        json.dump(results, out_file, ensure_ascii=False, indent=4)


if __name__ == '__main__':
    try:
        app()
    except Exception as e:
        print(f"程序出现未捕获的异常: {e}")
        import traceback
        traceback.print_exc()