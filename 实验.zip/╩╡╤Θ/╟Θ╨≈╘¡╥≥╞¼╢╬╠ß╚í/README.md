在下面链接中下载qwen模型

[[Qwen/Qwen2.5-7B-Instruct at main](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct/tree/main)](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct/blob/main/generation_config.json)

