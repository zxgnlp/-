import os
import math
import pathlib
from typing import Optional, Dict, List
from dataclasses import dataclass, field
import json

import torch
from torch.utils.data import Dataset
import transformers
from transformers.training_args import TrainingArguments


@dataclass
class ModelArguments:
    model_name_or_path: Optional[str] = field(default="Qwen/Qwen2.5-7B-Instruct")


@dataclass
class DataArguments:
    data_path: str = field(
        default=None, metadata={"help": "Path to the training data."}
    )
    eval_data_path: Optional[str] = field(
        default=None, metadata={"help": "Path to the evaluation data."}
    )


@dataclass
class TrainingArguments(transformers.TrainingArguments):
    cache_dir: Optional[str] = field(default=None)
    optim: str = field(default="adamw_torch")
    model_max_length: int = field(
        default=512,
        metadata={
            "help": "Maximum sequence length. Sequences will be right padded (and possibly truncated)."
        },
    )
    use_lora: bool = field(default=False)


def load_data(path: str) -> List[dict]:
    """
    兼容 json 和 jsonl 格式的加载函数。
    """
    if not os.path.exists(path):
        print(f"Warning: Path {path} does not exist.")
        return []
    
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
        
        # 尝试作为完整的 JSON 数组加载
        try:
            data = json.loads(content)
            if isinstance(data, list):
                return data
        except json.JSONDecodeError:
            pass
        
        # 如果 JSON 解析失败，则作为 JSONL 加载
        data = []
        for line in content.splitlines():
            line = line.strip()
            if line:
                try:
                    data.append(json.loads(line))
                except json.JSONDecodeError:
                    print(f"Skipping invalid line: {line}")
        return data


class SupervisedDataset(Dataset):
    """Dataset for Qwen2.5 supervised fine-tuning."""

    def __init__(
        self,
        data_path,
        tokenizer,
        model_max_length,
    ):
        super(SupervisedDataset, self).__init__()
        self.data = load_data(data_path)
        self.tokenizer = tokenizer
        self.model_max_length = model_max_length
        self.ignore_index = -100
        
        # <--- 修改：不再使用 user_tokens/assistant_tokens，使用 apply_chat_template 自动处理
        
        if len(self.data) > 0:
            try:
                item = self.preprocessing(self.data[0])
                print("input:", self.tokenizer.decode(item["input_ids"]))
                # 仅打印非 ignore_index 的部分以便检查
                labels = []
                for id_ in item["labels"]:
                    if id_ == -100:
                        continue
                    labels.append(id_)
                print("label:", self.tokenizer.decode(labels))
            except Exception as e:
                print(f"Error in preprocessing first example: {e}")
        else:
            print("Warning: Dataset is empty!")

    def __len__(self):
        return len(self.data)

    def preprocessing(self, example):
        """
        使用 apply_chat_template 处理 Qwen2.5 格式
        """
        # 1. 映射数据 key：human -> user, gpt -> assistant
        messages = []
        for message in example["conversations"]:
            role = message["from"]
            if role in ["human", "user"]:
                messages.append({"role": "user", "content": message["value"]})
            elif role in ["gpt", "assistant"]:
                messages.append({"role": "assistant", "content": message["value"]})
        
        # 2. 应用 ChatML 模板
        # tokenize=True 自动生成 token ids
        template_dict = self.tokenizer.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=False, # 训练数据不需要生成提示
            return_dict=True
        )
        
        input_ids = template_dict["input_ids"]
        
        # 3. 构建 Labels (Mask 掉 Prompt，只保留 Assistant 的回复)
        labels = [self.ignore_index] * len(input_ids)
        
        # 查找 assistant 开始的位置
        # 获取 <|im_start|> 和 <|im_end|> 的 token id
        im_start_id = self.tokenizer.convert_tokens_to_ids("<|im_start|>")
        im_end_id = self.tokenizer.convert_tokens_to_ids("<|im_end|>")
        
        is_assistant = False
        for i, token_id in enumerate(input_ids):
            if token_id == im_start_id:
                # 检查下一个 token 是否为 "assistant"
                if i + 1 < len(input_ids):
                    next_token = input_ids[i+1]
                    # 获取 "assistant" 的 token id (可能包含换行符等)
                    assistant_id = self.tokenizer.convert_tokens_to_ids("assistant")
                    # 这里做一个简单的字符串匹配检查更稳健，但在 token level 下，检查 id 即可
                    if next_token == assistant_id: 
                        is_assistant = True
            
            elif token_id == im_end_id:
                is_assistant = False
            
            if is_assistant:
                # 注意：这里会把 "assistant" 这个词本身也计算 loss，这是常规做法
                # 如果只想算回复内容，可以稍作延迟
                labels[i] = token_id

        # 4. 截断与 Padding
        # 截断
        if len(input_ids) > self.model_max_length:
            input_ids = input_ids[:self.model_max_length]
            labels = labels[:self.model_max_length]
        
        # Padding
        pad_len = self.model_max_length - len(input_ids)
        input_ids += [self.tokenizer.pad_token_id] * pad_len
        labels += [self.ignore_index] * pad_len
        
        return {
            "input_ids": torch.LongTensor(input_ids),
            "labels": torch.LongTensor(labels),
            "attention_mask": torch.LongTensor([1] * len(input_ids)) # mask 不需要 pad token 0，因为 pad 已经设为 0 了，这里设为 1 表示有效
        }

    def __getitem__(self, idx) -> Dict[str, torch.Tensor]:
        return self.preprocessing(self.data[idx])


def train():
    parser = transformers.HfArgumentParser(
        (ModelArguments, DataArguments, TrainingArguments)
    )
    model_args, data_args, training_args = parser.parse_args_into_dataclasses()

    model = transformers.AutoModelForCausalLM.from_pretrained(
        model_args.model_name_or_path,
        trust_remote_code=True,
        cache_dir=training_args.cache_dir,
        # 建议添加低精度模式以节省显存
        torch_dtype=torch.bfloat16 
    )
    tokenizer = transformers.AutoTokenizer.from_pretrained(
        model_args.model_name_or_path,
        use_fast=False,
        trust_remote_code=True,
        model_max_length=training_args.model_max_length,
        cache_dir=training_args.cache_dir,
    )
    
    # 设置 pad_token
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    if training_args.use_lora:
        from peft import LoraConfig, TaskType, get_peft_model

        # <--- 修改：适配 Qwen 的 LoRA 配置 ---
        peft_config = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"], # 常用全量微调层
            inference_mode=False,
            r=64,            # Qwen 常用 64
            lora_alpha=16,   # Qwen 常用 16
            lora_dropout=0.1,
        )
        model.enable_input_require_grads()
        model = get_peft_model(model, peft_config)
        model.print_trainable_parameters()

    train_dataset = SupervisedDataset(
        data_args.data_path, tokenizer, training_args.model_max_length
    )
    
    eval_dataset = None
    if data_args.eval_data_path and os.path.exists(data_args.eval_data_path):
        print(f"Loading evaluation data from {data_args.eval_data_path}")
        eval_dataset = SupervisedDataset(
            data_args.eval_data_path, tokenizer, training_args.model_max_length
        )

    trainer = transformers.Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        tokenizer=tokenizer
    )
    
    if eval_dataset is not None:
        if training_args.evaluation_strategy == "no":
             training_args.evaluation_strategy = "epoch"
        if training_args.save_strategy == "no":
             training_args.save_strategy = "epoch"
             
        print("Evaluation strategy set to 'epoch'.")

    trainer.train()
    trainer.save_state()
    trainer.save_model(output_dir=training_args.output_dir)


if __name__ == "__main__":
    train()
