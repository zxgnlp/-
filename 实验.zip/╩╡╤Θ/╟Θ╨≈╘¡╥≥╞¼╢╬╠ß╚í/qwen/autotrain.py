import os
import re
import json
import subprocess
from pathlib import Path
from tqdm import tqdm
from collections import defaultdict
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
import torch
import gc

class BaichuanFixedFoldTrainer:
    def __init__(self, data_dir: str, base_model_path: str, output_root: str, num_folds=10):
        self.data_dir = Path(data_dir)
        self.base_model_path = Path(base_model_path)
        self.output_root = Path(output_root)
        self.num_folds = num_folds

        self.output_root.mkdir(parents=True, exist_ok=True)
        # Qwen 训练脚本路径
        self.train_script = "/data/zxg/z-Contrast-exp/qwen/finetune2.py"
        self.ds_config_template = "/data/zxg/z-Contrast-exp/qwen/ds_config_zero2.json"
        
        self.training_args = {
            "num_train_epochs": 10,
            "per_device_train_batch_size": 1,
            "gradient_accumulation_steps": 1,
            "learning_rate": 2e-5,
            "model_max_length": 512,
            "use_lora": True,
        }

    def _run_command(self, command, log_file_path):
        """执行一个 shell 命令并将输出和错误重定向到日志文件"""
        print(f"\n🚀 Executing: {' '.join(command)}")
        print(f"📝 Log will be saved to: {log_file_path}")
        try:
            full_command = f"{' '.join(command)} > {log_file_path} 2>&1"
            process = subprocess.Popen(full_command, shell=True)
            process.wait()
            
            if process.returncode != 0:
                print(f"❌ Error: Command failed with exit code {process.returncode}. Check log for details.")
                try:
                    with open(log_file_path, 'r') as f:
                        lines = f.readlines()
                        print("Last 10 lines of error log:")
                        for line in lines[-10:]:
                            print(line.strip())
                except Exception:
                    pass
                raise RuntimeError(f"Command failed: {' '.join(command)}")
            else:
                print("✅ Command executed successfully.")
                
        except Exception as e:
            raise RuntimeError(f"Failed to execute command: {e}")

    def run_training(self, fold):
        """为指定的 fold 执行训练。"""
        fold_dir = self.output_root / f"fold_{fold}"
        train_data_path = self.data_dir / f"train{fold}.json"
        val_data_path = self.data_dir / f"val{fold}.json"
        output_dir = fold_dir / "output"
        #ds_config_path = fold_dir / "ds_config_zero2.json"
        train_log_path = fold_dir / "train.log"

        fold_dir.mkdir(parents=True, exist_ok=True)
        output_dir.mkdir(parents=True, exist_ok=True)

        # 检查是否已训练 (LoRA 检查 adapter_config.json)
        if (output_dir / "adapter_config.json").exists() if self.training_args["use_lora"] else (output_dir / "pytorch_model.bin").exists():
            print(f"✅ Fold {fold} 模型已存在，跳过训练。")
            return

        if not train_data_path.exists() or not val_data_path.exists():
            print(f"⚠️ Fold {fold} 的数据文件未找到，跳过训练。")
            return

        print(f"\n{'='*20} Starting Training for Fold {fold}/{self.num_folds} {'='*20}")
        
        # 准备 DeepSpeed 配置
        # if not Path(self.ds_config_template).exists():
        #     raise FileNotFoundError(f"DeepSpeed 配置模板文件未找到: {self.ds_config_template}")
        # with open(self.ds_config_template, 'r') as f_in, open(ds_config_path, 'w') as f_out:
        #     f_out.write(f_in.read())
        master_port = 29500 + fold

        # 构建训练命令
        train_command = [
            # "deepspeed", "--include=localhost:1", self.train_script,
            "torchrun", 
            "--nproc_per_node", "1", # 单卡
            "--master_port", str(master_port), # 固定端口防止冲突
            self.train_script,
            
            "--data_path", str(train_data_path),
            "--eval_data_path", str(val_data_path),
            "--model_name_or_path", str(self.base_model_path),
            "--output_dir", str(output_dir),
            "--model_max_length", str(self.training_args["model_max_length"]),
            "--num_train_epochs", str(self.training_args["num_train_epochs"]),
            "--per_device_train_batch_size", str(self.training_args["per_device_train_batch_size"]),
            "--gradient_accumulation_steps", str(self.training_args["gradient_accumulation_steps"]),
            "--learning_rate", str(self.training_args["learning_rate"]),
            # "--deepspeed", str(ds_config_path),
            "--bf16", "True",
            "--tf32", "True",
            "--use_lora", "True",
            "--gradient_checkpointing", "True",
            "--report_to", "none",
            "--save_steps", "1000", 
            "--save_strategy", "steps",
        ]
        if self.training_args["use_lora"]:
            train_command.extend(["--use_lora", "True"])

        self._run_command(train_command, train_log_path)
        print(f"✅ Fold {fold} 训练完成。日志保存在 {train_log_path}")

    def run_inference_and_evaluation(self, fold):
        """对训练好的模型的所有 checkpoint 进行推理和评估。"""
        fold_dir = self.output_root / f"fold_{fold}"
        summary_path = fold_dir / f"fold_{fold}_results.json"
        
        if summary_path.exists():
            print(f"\n🚫 Fold {fold} 结果文件已存在 ({summary_path.name})，跳过推理和评估。")
            return

        test_data_path = self.data_dir / f"test{fold}.json"
        output_dir = fold_dir / "output"
        
        if not output_dir.exists():
            print(f"⚠️ 模型输出目录不存在，跳过评估: {output_dir}")
            return

        print(f"\n{'='*20} Starting Evaluation for Fold {fold}/{self.num_folds} {'='*20}")

        # 显式清理显存
        gc.collect()
        torch.cuda.empty_cache()

        # 加载测试数据
        test_dataset = self._load_jsonl(test_data_path)
        true_causes = self._extract_causes_from_dataset(test_dataset)

        # 发现并筛选 checkpoint (只保留 1000 的倍数)
        raw_ckpts = [d for d in output_dir.glob("checkpoint-*") if d.is_dir()]
        if not raw_ckpts:
            print(f"⚠️ 没有找到任何 checkpoint in {output_dir}, 跳过评估")
            return
            
        def ckpt_key(p): 
            match = re.search(r"checkpoint-(\d+)", p.name)
            return int(match.group(1)) if match else 0

        checkpoints = []
        for ckpt in raw_ckpts:
            step = ckpt_key(ckpt)
            if step > 0 and step % 1000 == 0:
                checkpoints.append(ckpt)
        
        checkpoints = sorted(checkpoints, key=ckpt_key)
        
        if not checkpoints:
             print(f"⚠️ 没有找到步数为 1000 倍数的 checkpoint，跳过评估")
             return

        all_results = {}
        best_ckpt = None
        best_f1 = -1.0

        # --- 3. 遍历所有 checkpoint ---
        for ckpt in checkpoints:
            step = re.search(r"checkpoint-(\d+)", ckpt.name).group(1)
            print(f"\n===== 正在评估 {ckpt.name} =====")

            # 加载模型
            try:
                # 在循环内重新加载 tokenizer 以确保每次都干净
                tokenizer = AutoTokenizer.from_pretrained(self.base_model_path, trust_remote_code=True)
                
                if self.training_args["use_lora"]:
                    # 强制 cuda:1
                    base_model = AutoModelForCausalLM.from_pretrained(
                        self.base_model_path, 
                        device_map={"": 1}, 
                        torch_dtype=torch.bfloat16, 
                        trust_remote_code=True,
                        low_cpu_mem_usage=True 
                    )
                    model = PeftModel.from_pretrained(base_model, str(ckpt), device_map={"": 1})
                else:
                    model = AutoModelForCausalLM.from_pretrained(
                        ckpt, 
                        device_map={"": 1}, 
                        torch_dtype=torch.bfloat16, 
                        trust_remote_code=True,
                        low_cpu_mem_usage=True
                    )
                model.eval()
                
            except Exception as e:
                print(f"❌ 加载模型失败 {ckpt}: {e}, 跳过该 checkpoint")
                continue

            # --- 推理 ---
            predictions = []
            for item in tqdm(test_dataset, desc=f"Fold {fold} - {ckpt.name} Inference"):
                user_input = item["conversations"][0]["value"]
                
                # --- 关键修改：使用 apply_chat_template ---
                # Qwen 必须加上 ChatML 格式才能正确回答
                messages = [{"role": "user", "content": user_input}]
                text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                
                inputs = tokenizer(text, return_tensors="pt").to("cuda:1")

                with torch.no_grad():
                    outputs = model.generate(
                        **inputs, 
                        max_length=2048, # Qwen2.5 支持更长，适当增加
                        do_sample=False,
                        eos_token_id=tokenizer.eos_token_id,
                        pad_token_id=tokenizer.pad_token_id
                    )
                
                input_len = inputs['input_ids'].shape[1]
                generated_tokens = outputs[0][input_len:]
                response = tokenizer.decode(generated_tokens, skip_special_tokens=True)
                
                predictions.append(response)

            # --- 评估 ---
            pred_causes = self._extract_causes_from_predictions(predictions)
            strict_metrics, char_metrics, _ = self.calculate_metrics(true_causes, pred_causes)
            
            result = {
                "strict": {"p": strict_metrics[0], "r": strict_metrics[1], "f1": strict_metrics[2]},
                "char": {"p": char_metrics[0], "r": char_metrics[1], "f1": char_metrics[2]},
            }
            all_results[f"checkpoint-{step}"] = result
            
            print(f"Strict F1: {strict_metrics[2]:.4f}")

            if strict_metrics[2] > best_f1:
                best_f1 = strict_metrics[2]
                best_ckpt = f"checkpoint-{step}"

            # --- 显存清理 ---
            del model
            if self.training_args["use_lora"]: 
                del base_model
            gc.collect()
            torch.cuda.empty_cache()

        # --- 保存结果 ---
        print(f"\n📝 正在保存 Fold {fold} 的结果...")
        
        if best_ckpt is None:
            all_results["best_checkpoint"] = {"name": "None", "strict_f1": 0.0}
        else:
            all_results["best_checkpoint"] = {"name": best_ckpt, "strict_f1": best_f1}

        summary_path = fold_dir / f"fold_{fold}_results.json"
        
        try:
            with open(summary_path, 'w', encoding='utf-8') as sf:
                json.dump(all_results, sf, ensure_ascii=False, indent=2)
            print(f"✅ 结果已成功保存到: {summary_path}")
        except Exception as e:
            print(f"❌ 保存结果失败: {e}")
            
        print(f"🏆 最佳 Checkpoint: {best_ckpt} (Strict F1: {best_f1:.4f})")


    # --- 辅助函数 ---
    def _load_jsonl(self, path: Path):
        data = []
        if not path.exists():
            print(f"⚠️ File not found: {path}")
            return []
            
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            
            # 1. 尝试直接作为标准 JSON 加载 (例如 [ {a:1}, {b:2} ])
            try:
                # 如果文件不为空且以 [ 开头，尝试直接 load
                if content.startswith('['):
                    data = json.loads(content)
                    return data
            except json.JSONDecodeError:
                # 如果不是标准 JSON，继续尝试 JSONL 解析
                pass

            # 2. 如果是 JSONL (每行一个 JSON)，逐行解析
            for line in content.splitlines():
                line = line.strip()
                if not line: # 跳过空行 (导致 char 2 报错的元凶)
                    continue
                try:
                    data.append(json.loads(line))
                except json.JSONDecodeError as e:
                    print(f"⚠️ Skipping invalid line in {path.name}: {line[:50]}... Error: {e}")
                    continue
        return data


    def _extract_causes_from_dataset(self, dataset):
        true_causes = []
        for item in dataset:
            assistant_response = ""
            
            # <--- 修改：同时检查 gpt 和 assistant，确保兼容性 ---
            for conv in item["conversations"]:
                role = conv["from"]
                if role == "gpt" or role == "assistant":
                    assistant_response = conv["value"] 
            # --------------------------------------------------
            
            # 解析逻辑保持不变
            try:
                causes = json.loads(assistant_response)
                if isinstance(causes, list):
                    true_causes.append([str(c).strip() for c in causes])
                else:
                    true_causes.append([str(causes).strip()])
            except json.JSONDecodeError:
                # 如果不是标准 JSON 字符串，尝试用正则提取
                match = re.search(r"\[(.*?)\]", assistant_response, flags=re.S)
                if match:
                    items = re.findall(r"'(.*?)'|\"(.*?)\"", match.group(1), flags=re.S)
                    causes = [s[0] or s[1] for s in items if s[0] or s[1]]
                    true_causes.append([c.strip() for c in causes])
                else:
                    true_causes.append([])
        return true_causes


    def _extract_causes_from_predictions(self, predictions):
        pred_causes = []
        for response in predictions:
            if not isinstance(response, str):
                response = str(response)
            match = re.search(r"\[(.*?)\]", response, flags=re.S)
            if match:
                items = re.findall(r"'(.*?)'|\"(.*?)\"", match.group(1), flags=re.S)
                causes = [s[0] or s[1] for s in items if s[0] or s[1]]
                pred_causes.append([c.strip() for c in causes])
            else:
                pred_causes.append([])
        return pred_causes

    def longest_common_subsequence(self, a: str, b: str) -> int:
        dp = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
        for i in range(len(a)):
            for j in range(len(b)):
                if a[i] == b[j]:
                    dp[i+1][j+1] = dp[i][j] + 1
                else:
                    dp[i+1][j+1] = max(dp[i][j+1], dp[i+1][j])
        return dp[-1][-1]

    def calculate_metrics(self, true_causes: list, pred_causes: list):
        strict_correct = 0
        total_strict_pred = sum(len(p) for p in pred_causes)
        total_strict_true = sum(len(t) for t in true_causes)
        char_correct = 0
        total_pred_chars = 0
        total_true_chars = 0

        for t_list, p_list in zip(true_causes, pred_causes):
            strict_set = set(t_list)
            pred_set = set(p_list)
            strict_correct += len(strict_set & pred_set)

            matched_true = defaultdict(bool)
            for p in p_list:
                best_match = (-1, 0)
                for i, t in enumerate(t_list):
                    if not matched_true[i]:
                        score = self.longest_common_subsequence(t, p)
                        if score > best_match[1]:
                            best_match = (i, score)
                if best_match[0] != -1:
                    matched_true[best_match[0]] = True
                    char_correct += best_match[1]
                total_pred_chars += len(p)
            for t in t_list:
                total_true_chars += len(t)

        strict_precision = strict_correct / total_strict_pred if total_strict_pred > 0 else 0
        strict_recall = strict_correct / total_strict_true if total_strict_true > 0 else 0
        strict_f1 = 2 * strict_precision * strict_recall / (strict_precision + strict_recall) if (strict_precision + strict_recall) > 0 else 0
        char_precision = char_correct / total_pred_chars if total_pred_chars > 0 else 0
        char_recall = char_correct / total_true_chars if total_true_chars > 0 else 0
        char_f1 = 2 * char_precision * char_recall / (char_precision + char_recall) if (char_precision + char_recall) > 0 else 0

        return ((strict_precision, strict_recall, strict_f1),
                (char_precision, char_recall, char_f1),
                (strict_correct, total_strict_pred, total_strict_true))

    def run_all_folds(self):
        for fold in range(0, self.num_folds + 1):
            try:
                self.run_training(fold)
                self.run_inference_and_evaluation(fold)
            except Exception as e:
                print(f"❌ Fold {fold} 处理过程中发生严重错误: {e}")
                import traceback
                traceback.print_exc()
                continue


if __name__ == '__main__':
    data_dir = "/data/zxg/z-Contrast-exp/qwen/data"
    base_model_path = "/data/LLMs/Qwen2.5-7B-Instruct-new/qwen/Qwen2.5-7B-Instruct"
    output_root = "/data/zxg/z-Contrast-exp/qwen/output"

    trainer = BaichuanFixedFoldTrainer(
        data_dir=data_dir,
        base_model_path=base_model_path,
        output_root=output_root,
        num_folds=10
    )
    
    trainer.run_all_folds()
