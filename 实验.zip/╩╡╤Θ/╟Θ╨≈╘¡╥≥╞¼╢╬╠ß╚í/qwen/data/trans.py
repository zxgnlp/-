import json
import os
from pathlib import Path
import uuid

# ================= 配置区域 =================
SOURCE_DATA_DIR = "/data/zxg/z-Contrast-exp/Baichuan2-7B-Base/fine-tune/data"
TARGET_DATA_DIR = "/data/zxg/z-Contrast-exp/qwen/data"
# ===========================================

def load_json_file(file_path):
    """
    尝试智能读取 JSON 或 JSONL 文件
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 方法 1: 尝试直接解析为标准 JSON (list 或 dict)
    try:
        data = json.loads(content)
        if isinstance(data, list):
            return data
        else:
            return [data] # 如果是单个对象，包成列表
    except json.JSONDecodeError:
        pass # 不是标准 JSON，尝试 JSONL
    
    # 方法 2: 尝试解析为 JSONL (多行)
    data = []
    for line in content.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            data.append(json.loads(line))
        except json.JSONDecodeError as e:
            print(f"⚠️ 跳过无法解析的行: {line[:50]}... Error: {e}")
    return data

def convert_single_file(source_path, target_path):
    """
    读取源文件，转换格式，写入目标文件
    """
    if not os.path.exists(source_path):
        print(f"⚠️ 源文件不存在，跳过: {source_path}")
        return

    # 读取旧数据 (支持 JSON 和 JSONL)
    data = load_json_file(source_path)
    print(f"📖 读取文件: {source_path} (共 {len(data)} 条)")
    
    new_data = []
    
    for idx, item in enumerate(data):
        # 生成唯一 ID
        unique_id = f"identity_{uuid.uuid4().hex[:8]}"
        
        # 转换 conversations 字段
        new_conversations = []
        
        if "conversations" in item:
            for turn in item["conversations"]:
                role = turn.get("from", "")
                value = turn.get("value", "")
                
                # 映射 Baichuan 格式 -> Qwen 格式
                if role == "human":
                    new_role = "user"
                elif role == "gpt":
                    new_role = "assistant"
                else:
                    new_role = role 
                
                new_conversations.append({
                    "from": new_role,
                    "value": value
                })
        else:
            print(f"⚠️ 跳过无 conversations 字段的条目: {item}")
            continue
            
        new_item = {
            "id": unique_id,
            "conversations": new_conversations
        }
        new_data.append(new_item)

    # 写入新文件 (Qwen 官方脚本通常支持标准 JSON 列表)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    with open(target_path, 'w', encoding='utf-8') as f:
        json.dump(new_data, f, ensure_ascii=False, indent=2)
    
    print(f"✅ 转换完成: {target_path}")

def main():
    # 确保目标根目录存在
    Path(TARGET_DATA_DIR).mkdir(parents=True, exist_ok=True)
    
    # 获取源目录下所有的 json 文件
    source_files = list(Path(SOURCE_DATA_DIR).glob("*.json"))
    
    print(f"🚀 开始转换数据格式...")
    print(f"📂 源目录: {SOURCE_DATA_DIR}")
    print(f"📂 目标目录: {TARGET_DATA_DIR}")
    print(f"🔍 发现 {len(source_files)} 个 JSON 文件\n")
    
    for source_file in source_files:
        # 构建目标文件路径，保持文件名不变
        target_file = Path(TARGET_DATA_DIR) / source_file.name
        
        # 执行转换
        convert_single_file(source_file, target_file)

    print("\n🎉 所有文件转换完成！")

if __name__ == "__main__":
    main()
